/* 
 *  fork() - POSIX 1003.1b 3.1.1
 *
 *  $Id: fork.c,v 1.1 1998/09/25 13:17:32 joel Exp $
 */

#include <sys/types.h>
#include <errno.h>

int fork( void )
{
  errno = ENOSYS;
  return -1;
}
