/*
 *  opendir() - POSIX 1003.1b - XXX
 *
 *  $Id: opendir.c,v 1.2 1998/10/22 16:15:40 joel Exp $
 */

#include <dirent.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>

DIR *opendir(
  const char *name
)
{
  return NULL;
}
