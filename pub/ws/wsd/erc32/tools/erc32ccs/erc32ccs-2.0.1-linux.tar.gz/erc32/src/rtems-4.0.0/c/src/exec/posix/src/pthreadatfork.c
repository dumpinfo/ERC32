/* 
 *  pthread_atfork() - POSIX 1003.1b 3.1.3
 *
 *  $Id: pthreadatfork.c,v 1.1 1998/09/25 13:17:32 joel Exp $
 */

#include <sys/types.h>
#include <errno.h>

int pthread_atfork(
  void (*prepare)(void),
  void (*parent)(void),
  void (*child)(void)
)
{
  errno = ENOSYS;
  return -1;
}
