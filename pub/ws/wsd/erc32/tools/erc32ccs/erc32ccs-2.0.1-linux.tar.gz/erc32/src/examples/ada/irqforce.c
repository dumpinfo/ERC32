#include <bsp.h>

irqforce(int irq)
{
  ERC32_Unmask_interrupt(irq);
  ERC32_Force_interrupt(irq);
}
