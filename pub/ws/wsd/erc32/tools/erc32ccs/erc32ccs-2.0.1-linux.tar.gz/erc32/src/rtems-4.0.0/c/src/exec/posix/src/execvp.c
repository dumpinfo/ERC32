/* 
 *  execvp() - POSIX 1003.1b 3.1.2
 *
 *  $Id: execvp.c,v 1.1 1998/09/25 13:17:32 joel Exp $
 */

#include <errno.h>

int execvp(
  const char *path,
  char const *argv[]
)
{
  errno = ENOSYS;
  return -1;
}
