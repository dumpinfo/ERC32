/*
 *  telldir() - XXX
 * 
 *  $Id: telldir.c,v 1.3 1998/10/22 16:15:40 joel Exp $
 */

#include <sys/param.h>
#include <assert.h>
#include <dirent.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

#include <rtems.h>
#include "libio.h"

long telldir(
  DIR *dirp
)
{
  errno = ENOSYS;
  return -1;
}
