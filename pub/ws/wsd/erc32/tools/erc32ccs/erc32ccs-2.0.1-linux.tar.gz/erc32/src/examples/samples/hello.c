
main()
{
	printf("Hello world!\n");
}
