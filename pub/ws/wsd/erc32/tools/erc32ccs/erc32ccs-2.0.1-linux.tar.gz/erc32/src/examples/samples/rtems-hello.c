/*
 * A simple rtems program to show how to use configuration templates
 */

#include <bsp.h>				/* get all rtems definitions */

rtems_task Init( rtems_task_argument argument);	/* forward declaration needed */

/* configuration information */

#define CONFIGURE_TEST_NEEDS_CONSOLE_DRIVER	/* enable console */
#define CONFIGURE_RTEMS_INIT_TASKS_TABLE	/* use default task table */
#define CONFIGURE_INIT				/* use default config table */
#include <confdefs.h>

rtems_task Init(
  rtems_task_argument ignored
)
{

  int o;
  printf( "Hello World\n" );
  o = *((int *) 0x8f00ff00);
  exit( 0 );
}
