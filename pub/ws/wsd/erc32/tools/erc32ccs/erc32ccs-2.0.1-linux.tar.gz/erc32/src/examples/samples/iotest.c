
main()
{
	volatile unsigned int * mec = 0x1f80000;
	volatile unsigned int * io0 = 0x10000000;
	volatile unsigned int * io1 = 0x11000000;
	volatile unsigned int * io2 = 0x12000000;
	volatile unsigned int * io3 = 0x13000000;

	printf("testing IO areas\n");
	mec[0x14/4] = 0x3f3f3034;
	io0[0] = 0; io0[1] = 1; io0[2] = 2; io0[3] = 3;
	io1[0] = 4; io1[1] = 5; io1[2] = 6; io1[3] = 7; io1[128] = 8;
	printf("%d %d %d %d %d\n", io0[0], io0[1], io0[2], io0[3], io0[129]);
	printf("%d %d %d %d %d\n", io1[0], io1[1], io1[2], io1[3], io1[129]);
	printf("test completed\n");
}
