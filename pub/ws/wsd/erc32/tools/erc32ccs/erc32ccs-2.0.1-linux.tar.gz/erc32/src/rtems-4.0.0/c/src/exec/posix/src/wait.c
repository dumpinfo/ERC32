/* 
 *  waitpid() - POSIX 1003.1b 3.2.1
 *
 *  $Id: wait.c,v 1.1 1998/09/27 16:37:16 joel Exp $
 */

#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>

int wait(
  int   *stat_loc
)
{
  errno = ENOSYS;
  return -1;
}
