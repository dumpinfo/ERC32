/*
 *  readdir() - POSIX 1003.1b - XXX
 *
 *  $Id: readdir.c,v 1.2 1998/10/22 16:15:40 joel Exp $
 */

#include <dirent.h>

struct dirent *readdir(
  register DIR *dirp
)
{
  return NULL;
}
