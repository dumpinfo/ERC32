/* rtems/posix/cancel.h
 *
 *  $Id: cancel.h,v 1.3 1995/12/19 20:00:43 joel Exp $
 */

#ifndef __RTEMS_POSIX_CANCEL_h
#define __RTEMS_POSIX_CANCEL_h

typedef struct {
  Chain_Node  Node;
  void      (*routine)( void * );
  void       *arg;
}  POSIX_Cancel_Handler_control;

#endif
/* end of include file */
