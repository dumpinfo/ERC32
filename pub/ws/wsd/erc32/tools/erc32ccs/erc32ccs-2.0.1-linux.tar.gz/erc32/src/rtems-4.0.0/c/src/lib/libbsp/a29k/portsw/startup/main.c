/*  main()
 *
 *  This is the entry point for the application.  It calls
 *  the bsp_start routine to the actual dirty work.
 *
 *  COPYRIGHT (c) 1989-1998.
 *  On-Line Applications Research Corporation (OAR).
 *  Copyright assigned to U.S. Government, 1994.
 *
 *  The license and distribution terms for this file may be
 *  found in the file LICENSE in this distribution or at
 *  http://www.OARcorp.com/rtems/license.html.
 *
 *  $Id: main.c,v 1.4 1998/02/17 23:44:32 joel Exp $
 */

#include <rtems.h>
#include <bsp.h>

#ifndef lint
static char _sccsid[] = "@(#)main.c 06/30/96     1.2\n";
#endif

int main(
  int   argc,
  char **argv,
  char **environp
)
{
  bsp_start( argc, argv, environp );

  /*
   *  May be able to return to the "crt/start.s" code but also
   *  may not be able to.  Do something here which is board dependent.
   */

  _exit(0);
  rtems_fatal_error_occurred( 0 );
}
