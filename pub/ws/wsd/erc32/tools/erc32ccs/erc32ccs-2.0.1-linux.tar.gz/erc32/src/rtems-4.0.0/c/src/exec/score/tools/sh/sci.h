#ifndef _shgen_sci_h
#define _shgen_sci_h

#include <stdio.h>

extern int shgen_gensci(
  FILE		*file,
  double	Phi /* Processor frequency [Hz] */
  );

#endif
