/* 
 *  execv() - POSIX 1003.1b 3.1.2
 *
 *  $Id: execv.c,v 1.2 1998/09/25 13:28:28 joel Exp $
 */

#include <errno.h>

int execv(
  const char *file,
  char *const argv[],
  ...
)
{
  errno = ENOSYS;
  return -1;
}
