/*
 *  closedir() - POSIX 1003.1b - XXX
 *
 *  $Id: closedir.c,v 1.2 1998/10/22 16:15:40 joel Exp $
 */


#include <sys/types.h>
#include <dirent.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

int closedir(
  register DIR *dirp
)
{
  errno = ENOSYS;
  return -1;
}
