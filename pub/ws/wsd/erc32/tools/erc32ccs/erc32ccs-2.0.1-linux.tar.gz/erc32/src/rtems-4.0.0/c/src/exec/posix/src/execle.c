/* 
 *  execle() - POSIX 1003.1b 3.1.2
 *
 *  $Id: execle.c,v 1.1 1998/09/25 13:17:31 joel Exp $
 */

#include <errno.h>

int execle(
  const char *path,
  char const *arg,
  ...
)
{
  errno = ENOSYS;
  return -1;
}
