/* 
 * we need a bsp.h in the rtems tree to keep the src/tests/...
 * happy.
 * But our bsp.h really lives in floss tree.
 *
 * Fake it out by installing this one in rtems
 *
 #  $Id: floss-bsp.h,v 1.1 1996/05/23 15:35:56 joel Exp $
 */

#include <floss/bsp.h>
