#define	USR	0xe8/4
#define TXA	0xe0/4
#define ERSR	0xb0/4

#define	SECMAX	32
#define	SECNAME	16

typedef struct sectype {
    unsigned int    paddr;
    unsigned int    raddr;
    unsigned int    len;
    unsigned int    comp;
    unsigned char   name[SECNAME];
}               tt;


extern char     filename[];
extern struct sectype sections[];
extern int      prot;

void
putsx(s)
    unsigned char  *s;
{
    volatile unsigned int *mec = (unsigned int *) 0x1f80000;

    while (s[0] != 0) {
	while ((mec[USR] & 4) == 0);
	mec[TXA] = *s;
	s++;
    }
}

memprotect(start, end)
    unsigned int    start, end;
{
    int             sbr, ser;
    volatile unsigned int *mec = (unsigned int *) 0x1f80000;

    mec[0x24 / 4] = ((end & 0x007fffff) >> 2);
    mec[0x20 / 4] = ((start & 0x007fffff) >> 2) | 0x01800000;
}

__main()
{
}

extern int ramsize, etext, freq;
void clean();
extern int Decode();

main()
{
    unsigned char  *p;
    int             paddr, raddr, len, secnum;
    void            (*prog) ();
    int             (*func) ();
    char    	    pbuf[8192];

    prog = (void *) sections[0].paddr;
    putsx("\n\n\r  ERC32 boot loader v1.0\n\n\r");
    mmov(clean,pbuf,0x100);
    mmov(Decode,(int)pbuf+0x100,0x200);
    putsx("  initialising RAM\n\r");
    func = (void *)pbuf;
    func(0x2000000,ramsize - 0x10000);
    secnum = 0;
    while (sections[secnum].paddr) {
	paddr = sections[secnum].paddr;
	raddr = sections[secnum].raddr;
	len = sections[secnum].len;
	if (sections[secnum].comp) {
            putsx("  decompressing ");
            putsx(sections[secnum].name);
            putsx("\n\r");
            func = (void *)((int)pbuf + 0x100);
	    if (func(raddr, paddr)) {
		putsx("  decompression failed \n\r");
	    }
		
        } else {
            putsx("  loading ");
            putsx(sections[secnum].name);
            putsx("\n\r");
            func = (void *)((int)mmov + (int)pbuf - (int)clean);
	    func(raddr, paddr,len);
 	}
	secnum++;
    }
    if (prot) {
	memprotect(sections[0].paddr + 0x1000, 
	    sections[0].paddr + sections[0].len);
        *((int *) (sections[0].paddr + 0x7e0)) = freq;
    }
    putsx("\n\r  starting ");
    putsx(filename);
    putsx("\n\n\r");
    prog();
}

void clean(paddr,len)
double *paddr;
int len;
{
    len >>=3;
    while (len >= 0) {
    	paddr[len] = 0;
	len--;
    }
}

mmov(raddr,paddr,len)
int *raddr, *paddr;
int len;
{
    len >>=2;
    while (len >= 0) {
    	paddr[len] = raddr[len];
	len--;
    }
}
