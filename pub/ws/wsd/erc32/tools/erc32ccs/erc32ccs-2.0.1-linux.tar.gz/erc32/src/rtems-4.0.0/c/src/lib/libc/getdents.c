/*
 *  Just enough to make newlib return an error.
 *
 *  $Id: getdents.c,v 1.1 1998/07/06 19:00:33 joel Exp $
 */

int getdents(
  int   fd,
  void *buf,
  int   len
)
{
  return -1;
}
