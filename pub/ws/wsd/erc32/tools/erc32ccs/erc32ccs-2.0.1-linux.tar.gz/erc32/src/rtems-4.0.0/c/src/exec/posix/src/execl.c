/* 
 *  execl() - POSIX 1003.1b 3.1.2
 *
 *  $Id: execl.c,v 1.1 1998/09/25 13:17:31 joel Exp $
 */

#include <errno.h>

int execl(
  const char *path,
  const char *arg,
  ...
)
{
  errno = ENOSYS;
  return -1;
}
