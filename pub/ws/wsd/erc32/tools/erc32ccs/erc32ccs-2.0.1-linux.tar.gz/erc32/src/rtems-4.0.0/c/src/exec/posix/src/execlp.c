/* 
 *  execlp() - POSIX 1003.1b 3.1.2
 *
 *  $Id: execlp.c,v 1.2 1998/09/25 13:28:28 joel Exp $
 */

#include <errno.h>

int execlp(
  const char *file,
  const char *arg,
  ...
)
{
  errno = ENOSYS;
  return -1;
}
