/*
 *  This routine performs final cleanup at exit time.
 *
 *  COPYRIGHT (c) 1989-1998.
 *  On-Line Applications Research Corporation (OAR).
 *  Copyright assigned to U.S. Government, 1994.
 *
 *  The license and distribution terms for this file may be
 *  found in the file LICENSE in this distribution or at
 *  http://www.OARcorp.com/rtems/license.html.
 *
 *  $Id: bspclean.c,v 1.1 1998/03/21 15:36:51 joel Exp $
 */

#include <bsp.h>

void bsp_cleanup( void )
{

   VME_interrupt_Disable( 0xff ); 
}
