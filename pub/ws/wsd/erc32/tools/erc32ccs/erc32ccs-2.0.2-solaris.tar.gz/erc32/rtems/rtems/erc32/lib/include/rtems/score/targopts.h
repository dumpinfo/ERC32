/* target board dependent options file */
/* automatically generated -- DO NOT EDIT!! */

#ifndef __TARGET_OPTIONS_h
#define __TARGET_OPTIONS_h

#ifdef sparc
#undef sparc
#endif
#define sparc 1

#ifdef erc32
#undef erc32
#endif
#define erc32 1

#ifdef erc32
#undef erc32
#endif
#define erc32 1

/* #define NDEBUG 1 */ 
#define RTEMS_TEST_NO_PAUSE 1
/* #define RTEMS_DEBUG  1 */
#define NO_TABLE_MOVE 1
#define CONSOLE_USE_INTERRUPTS 0
#define CONSOLE_USE_POLLED ~CONSOLE_USE_INTERRUPTS
/* #define SIMSPARC_FAST_IDLE 1 */
#define USE_INLINES 1
#define RTEMS_POSIX_API 1
#define RTEMS_NEWLIB 1
#define MALLOC_PROVIDED 1

#endif
