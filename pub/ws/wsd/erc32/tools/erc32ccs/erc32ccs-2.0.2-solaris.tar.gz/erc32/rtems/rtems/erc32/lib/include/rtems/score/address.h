/*  address.h
 *
 *  This include file contains the information required to manipulate
 *  physical addresses.
 *
 *  COPYRIGHT (c) 1989-1998.
 *  On-Line Applications Research Corporation (OAR).
 *  Copyright assigned to U.S. Government, 1994.
 *
 *  The license and distribution terms for this file may be
 *  found in the file LICENSE in this distribution or at
 *  http://www.OARcorp.com/rtems/license.html.
 *
 *  $Id: address.h,v 1.10 1998/02/17 23:44:20 joel Exp $
 */

#ifndef __RTEMS_ADDRESSES_h
#define __RTEMS_ADDRESSES_h

#ifdef __cplusplus
extern "C" {
#endif

#include <rtems/score/address.inl>

#ifdef __cplusplus
}
#endif

#endif
/* end of include file */
