/*
 *  Is <sys/signal.h> really necessary for RTEMS?
 *
 *  For sure we want to keep newlib's default version out of the install
 *  so this empty file helps out in that regards.
 */
