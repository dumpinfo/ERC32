/* Stand-alone library for SPARClite
 *
 * Copyright (c) 1995 Cygnus Support
 *
 * The authors hereby grant permission to use, copy, modify, distribute,
 * and license this software and its documentation for any purpose, provided
 * that existing copyright notices are retained in all copies and that this
 * notice is included verbatim in any distributions. No written agreement,
 * license, or royalty fee is required for any of the authorized uses.
 * Modifications to this software may be copyrighted by their authors
 * and need not follow the licensing terms described here, provided that
 * the new terms are clearly indicated on the first page of each file where
 * they apply.
 */

asm("
	.text
	.globl _rdtbr
_rdtbr:
	retl
	mov	%tbr, %o0

");

extern unsigned long rdtbr();


/* Each entry in the trap vector occupies four words. */

/*
struct trap_entry
{
  unsigned sethi_filler:10;
  unsigned sethi_imm22:22;
  unsigned jmpl_filler:19;
  unsigned jmpl_simm13:13;
  unsigned long filler[2];
};

extern struct trap_entry fltr_proto;
asm ("
	.data
	.globl _fltr_proto
	.align 4
_fltr_proto:			! First level trap routine prototype
	sethi 0, %l0
	jmpl 0+%l0, %g0
	nop
	nop

	.text
	.align 4
");

void
exceptionHandler(tt, routine)
     int tt;
     unsigned long routine;
{
  struct trap_entry *tb;

  tb = (struct trap_entry *)(rdtbr() & ~0xfff);

  tb[tt] = fltr_proto;

  tb[tt].sethi_imm22 = routine >> 10;
  tb[tt].jmpl_simm13 = routine & 0x3ff;
}

*/

#define RXADATA 0xE0/4
#define RXBDATA 0xE4/4
#define RXSTAT  0xE8/4

int read (fd, buf, nbyte)
int fd;
char *buf;
int nbyte;
{

	volatile int *mec = (int *) 0x01f80000;
        int rxmask,rxadata,rxstat,errmask,clrmask;
	int nsave;

	nsave = nbyte;
	switch (fd) {
		case 0 : 
			rxadata = RXADATA;
			rxmask = 1;
			errmask = 0x00000070;
			clrmask = 0x00000080;
			break;
		case 3 : 
			rxadata = RXBDATA;
			rxmask = 0x10000;
			errmask = 0x00700000;
			clrmask = 0x00800000;
			break;
		default:
			return (-1);
	}
        while (nbyte > 0) {
		while (((rxstat = mec[RXSTAT]) & rxmask) == 0)
			if (rxstat & errmask) {
				mec[RXSTAT] = clrmask;
				mec[0] = mec[0];
			}
		*buf =  (char) mec[rxadata];
		buf++;
                nbyte--;
	}
	return (nsave);
}

int write (fd, buf, nbyte)
int fd;
char *buf;
int nbyte;
{

	volatile int *mec = (int *) 0x01f80000;
	int nlfilt = 0;
        int rxadata;
        int rxmask;
	int nsave;

	nsave = nbyte;

	switch (fd) {
		case 1 : 
		case 2 : 
			rxadata = RXADATA;
			rxmask = 4;
			nlfilt = 1;
			break;
		case 4 : 
		case 5 : 
			rxadata = RXBDATA;
			rxmask = 0x40000;
			break;
		default:
			return (-1);
	}
        while (nbyte > 0) {
		while ((mec[RXSTAT] & rxmask) == 0);
		mec[rxadata] = (0x0ff & *buf);
		if (nlfilt && (*buf == '\n')) {
			while ((mec[RXSTAT] & rxmask) == 0);
			mec[rxadata] = (int) '\r';
		}
		buf++;
		nbyte--;
	}
	return (nsave);
}

/* NOTE: This code depends on the definition of `__jmp_buf' in <jmp_buf.h>.  */
	/* Do a "flush register windows trap".  The trap handler in the
	   kernel writes all the register windows to their stack slots, and
	   marks them all as invalid (needing to be sucked up from the
	   stack when used).  This ensures that all information needed to
	   unwind to these callers is in memory, not in the register
	   windows.  */

  asm("
	.text
	.global __longjmp
__longjmp:
	ta 3			!ST_FLUSH_WINDOWS
	ld [%o0], %o7		/* Return PC.  */
	ld [%o0 + 4], %fp	/* Saved SP.  */
	sub %fp, 64, %sp	/* Allocate a register save area.  */

	/* if (%o1 == 0) %o1 = 1; */
	tst %o1
	be,a Ldone
	mov 1, %o1

Ldone:	retl
	/* On the way out, put the return value in %o0.  */
	restore %o1, 0, %o0

	.global __setjmp
__setjmp:
	/* Save our return PC and SP.  */
	st %o7, [%o0]
	st %sp, [%o0 + 4]
	retl
	clr %o0

  ");


int
close(int _fd)
{
  /* return value usually ignored anyhow */
  return 0;
}
 
int
open(char *filename)
{
  /* always fail */
  return -1;
}
 

