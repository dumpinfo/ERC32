

#define MAGIC_NUMBER '\xaa'
#define PH_SIZE 12
#define EOP '\x55'

typedef struct {
  char MAGIC;
  unsigned char PARAMS;
  unsigned char CHECKSUM;
  unsigned long ENCODED_SIZE;
  unsigned long DECODED_SIZE;
} packet_header;


unsigned char
Decode(unsigned char *in_buffer,
       unsigned char *out_buffer)
     /* Just the reverse of Encode(). */
{
  int  i, j, k, r, c, in_ctr, out_ctr;
  unsigned int  flags;
  unsigned char checksum = 0xff, CHECKSUM;
  packet_header *PH;
  unsigned long LHS, WS, ES, DS;
  unsigned char THRESH;
  char ring_buffer[4096];
 
  PH = (packet_header *) in_buffer;
 
  if (PH->MAGIC != MAGIC_NUMBER) return 1;
 
  WS= (PH->PARAMS & 0xf0) << 6; /* the value of N is the 4 most significant
                                         bit multiplied by 1024 */
  LHS= (1 << ((PH->PARAMS & 0x0c) >> 2)) * 9; /* valid values for F are
                                               9,18,36,72 */
 
  THRESH = (PH->PARAMS & 0x03) + 1; /* valid values for the threshold are
                                                1,2,3,4 */
  CHECKSUM = PH->CHECKSUM;
  ES = PH->ENCODED_SIZE;
  DS = PH->DECODED_SIZE;
 
  in_buffer += PH_SIZE;
 
  in_ctr = out_ctr = 0;
 
  for (i = 0; i < WS - LHS; i++) ring_buffer[i] = ' ';
  r = WS - LHS;
  flags = 0;
 
  for ( ; ; ) {
    if (((flags >>= 1) & 256) == 0) {
      if (in_ctr == ES) break;
      c = in_buffer[in_ctr++];
      flags = c | 0xff00;               /* uses higher byte cleverly */
    }                                                   /* to count eight */
    if (flags & 1) {
      if (in_ctr == ES) break;
      c = in_buffer[in_ctr++];
      out_buffer[out_ctr++] = c;
      checksum ^= c;
      ring_buffer[r++] = c;
      r &= (WS - 1);
    }
    else {
      if (in_ctr == ES) break;
      i = in_buffer[in_ctr++];
      if (in_ctr == ES) break;
      j = in_buffer[in_ctr++];
      i |= ((j & 0xf0) << 4);
      j = (j & 0x0f) + THRESH;
      for (k = 0; k <= j; k++) {
        c = ring_buffer[(i + k) & (WS - 1)];
        out_buffer[out_ctr++] = c;
        checksum ^= c;
        ring_buffer[r++] = c;
        r &= (WS - 1);
      }
    }
  }
 
  if (checksum != CHECKSUM) return 2; /* checksum error */
  if (in_buffer[in_ctr++] != EOP) return 3; /* EOP not found error */
  in_buffer += in_ctr;
  out_buffer += out_ctr;
  return 0;
}

