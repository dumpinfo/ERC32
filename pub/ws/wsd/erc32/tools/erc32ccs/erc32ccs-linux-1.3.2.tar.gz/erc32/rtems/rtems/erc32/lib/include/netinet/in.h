/*
 *  Network support: endian conversion routines
 */


#ifndef __NETINET_IN_h
#define __NETINET_IN_h

#include <rtems/system.h>

#if ( CPU_HAS_OWN_HOST_TO_NETWORK_ROUTINES == FALSE )

#if ( CPU_BIG_ENDIAN == TRUE )

/*
 *  Very simply on big endian CPUs
 */

#define       ntohl(_x)        (_x)
#define       ntohs(_x)        (_x)
#define       htonl(_x)        (_x)
#define       htons(_x)        (_x)

#elif ( CPU_LITTLE_ENDIAN == TRUE )

/*
 *  A little more complicated on little endian CPUs
 */

#define       ntohl(_x)        ((long)  CPU_swap_u32((unsigned32)_x))
#define       ntohs(_x)        ((short) CPU_swap_u32((unsigned32)_x))
#define       htonl(_x)        ((long)  CPU_swap_u32((unsigned32)_x))
#define       htons(_x)        ((short) CPU_swap_u32((unsigned32)_x))

#else
#error "Unknown endian-ness for this cpu"
#endif

#endif  /* CPU_HAS_OWN_HOST_TO_NETWORK_ROUTINES */

#endif
/* end of include file */
