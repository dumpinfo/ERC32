/*
 * This file is part of SIS.
 * 
 * SIS, SPARC instruction simulator. Copyright (C) 1995 Jiri Gaisler, European
 * Space Agency
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 675
 * Mass Ave, Cambridge, MA 02139, USA.
 * 
 */

#include <string.h>
#include <stdio.h>
#include <dis-asm.h>

struct disassemble_info dinfo;
char            sec_name[64] = "";
int             verbose = 0;
int             critical = 0;

#ifndef fprintf
extern          fprintf();
#endif				/* ; */

extern int      buf_read();

main(argc, argv)
  int             argc;
  char          **argv;
{

  int             cont = 1;
  int             stat = 1;
  int             freq = 14;
  int             copt = 0;

  int             i, last_load_addr;

  INIT_DISASSEMBLE_INFO(dinfo, stdout, (fprintf_ftype) fprintf);
  dinfo.endian = BFD_ENDIAN_BIG;
  dinfo.read_memory_func = buf_read;

  while (stat < argc) {
    if (argv[stat][0] == '-') {
      if (strcmp(argv[stat], "-sec") == 0) {
	if ((stat + 1) < argc)
	  strcpy(sec_name, argv[++stat]);
      } else if (strcmp(argv[stat], "-v") == 0) {
	verbose = 1;
        printf("\nfcheck version 1.3, copyright Jiri Gaisler 1998\n");
      } else if (strcmp(argv[stat], "-c") == 0) {
	critical = 1;
      } else {
	printf("unknown option %s\n", argv[stat]);
	exit(1);
      }
    } else {
      last_load_addr = bfd_load(argv[stat]);
    }
    stat++;
  }
}



#include <ansidecl.h>

#ifdef ANSI_PROTOTYPES
#include <stdarg.h>
#else
#include <varargs.h>
#endif

#include <libiberty.h>
#include <bfd.h>

#define min(A, B) (((A) < (B)) ? (A) : (B))
#define LOAD_ADDRESS 0

extern struct disassemble_info dinfo;
extern int      verbose;

char           *buffer;

int
bfd_load(fname)
  char           *fname;
{
  int             cc, c;
  unsigned char   buf[10];
  asection       *section;
  bfd            *pbfd;
  unsigned long   entry;

  pbfd = bfd_openr(fname, 0);

  if (pbfd == NULL) {
    printf("ERROR 4 open of %s failed\n", fname);
    return (-1);
  }
  if (!bfd_check_format(pbfd, bfd_object)) {
    printf("ERROR 5 file %s  doesn't seem to be an object file\n", fname);
    return (-1);
  }
  if (verbose)
    printf("loading %s:\n", fname);
  for (section = pbfd->sections; section; section = section->next) {
    if (bfd_get_section_flags(pbfd, section) & SEC_ALLOC) {
      bfd_vma         section_address;
      unsigned long   section_size;
      const char     *section_name;
      int             sec_start;

      section_name = bfd_get_section_name(pbfd, section);

      section_address = bfd_get_section_vma(pbfd, section);
      /*
       * Adjust sections from a.out files, since they don't carry their
       * addresses with.
       */
      if (bfd_get_flavour(pbfd) == bfd_target_aout_flavour)
	section_address += (sec_start = bfd_get_start_address(pbfd));
      section_size = bfd_section_size(pbfd, section);


      /* Text, data or lit */
      if (bfd_get_section_flags(pbfd, section) & SEC_LOAD) {
	file_ptr        fptr;

	fptr = 0;

	if ((section_size > 0) &&
	    ((strcmp(".text", section_name) == 0) ||
	     (strcmp(".usr_txt", section_name) == 0) ||
	     (strcmp(".rts_txt", section_name) == 0) ||
	     (strcmp(".sec1", section_name) == 0) ||
	     (strcmp(sec_name, section_name) == 0)
	     )
	  ) {
	  int            *ibuf, j, rs1, rs2, rd, op1, op2, fdest, fdest2 ;
	  const int       op_mask =  0xc1f80000;
	  const int       ld_mask =  0xc1000000;
	  const int       ldd_mask = 0xc1180000;
	  const int       lb_mask =  0x00100000;
	  const int       std_mask = 0xc1380000;
	  const int       st_mask = 0xc1200000;
	  const int       ldfsr_mask = 0xc1080000;
	  const int       stfsr_mask = 0xc1280000;
	  const int       FPop_mask = 0xc1f00000;
	  const int       FPop      = 0x81a00000;
	  int             err = 0;
	  int             errcase = 0;

	  if (verbose)
	    printf("checking section %s at 0x%08lx (%ld bytes)\n",
		   section_name, section_address, section_size);
	  ibuf = (int *) memalign(4, section_size + 128);
	  buffer = (char *) ibuf;

	  bfd_get_section_contents(pbfd, section, buffer, fptr, section_size);

	  section_size = (section_size / 4) - 1;


 	  pbfd->xvec->bfd_putx32(ibuf[0],(bfd_byte *) &op2);

	  for (j = 0; j < (section_size); j++) {

    	    op1 = op2;
 	    pbfd->xvec->bfd_putx32(ibuf[j+1],(bfd_byte *) &op2);

	    /* Check fot ldd/std errors, CASE 1 */

	    if (((op1 & op_mask) == ldd_mask) &&
	       ((op2 & op_mask) == std_mask)) {
		fdest = (op1 >> 25) & 0x1f;
		rs1 = (op2 >> 14) & 0x1f;
		rd = (op2 >> 25) & 0x1f;
		if ((fdest == rs1) && (fdest != rd)) {
		  printf("ERROR 1 at %08x, (lddf/stdf)\n", j * 4 + section_address);
		  errcase = 1;
		  err++;
		}
	    }

	    /* Check for ld(d)/FPop(s/d) errors, CASE 2 

The following errors are considered:

 1. Single-precision load followed by single-precision store or FPop

	ld 	[..], %fN
	FPops 	%fX, %fY, %fZ
    
	ld 	[..], %fN
	st 	%fX, [..]
    
    Error is flagged if N=X or N=Y. 

 2. Single-precision load followed by double-precision store or FPop

	ld 	[..], %fN
	FPopd 	%fX, %fY, %fZ
    
	ld 	[..], %fN
	std 	%fX, [..]
    
    Error is flagged if N=X or N=Y. Note that N is truncated to an even
    value since double-precision FPop always use even %f registers.


 3. Double-precision load followed by single-precision load or FPop

	ldd 	[..], %fN
	FPops 	%fX, %fY, %fZ

	ldd 	[..], %fN
	st 	%fX, [..]
    
    
    Error is flagged if N=X or N=Y. Note that X and Y are truncated to an even
    value since double-precision load always use even %f registers.

 3. Double-precision load followed by double-precision load or FPop

	ldd 	[..], %fN
	FPop 	%fX, %fY, %fZ

	ldd 	[..], %fN
	std 	%fX, [..]
    
    Error is flagged if N=X or N=Y.

*/

	    if ((!critical) && (!errcase)) { 
	      if ((op1 & op_mask) == ld_mask) {
	        if ((op2 & FPop_mask) == FPop) {
		  fdest = (op1 >> 25) & 0x1f;
		  rs1 = (op2 >> 14) & 0x1f;
		  rs2 = (op2) & 0x1f;
		  if ((op2 >> 5) & 1) {	/* ldf/FPops */
		    if ((fdest == rs1) ||
		      ((((op2 >> 11) & 0x3) == 1) && (fdest == rs2))) {
		      printf("ERROR 3 at %08x, (ldf/FPops)\n", j * 4 + section_address);
		      errcase = 3;
		      err++;
		    }
		  } else {
		    fdest &= ~1;	/* ldf/FPopd */
		    if ((fdest == rs1) ||
		      ((((op2 >> 11) & 0x3) == 1) && (fdest == rs2))) {
		      printf("ERROR 3 at %08x, (ldf/FPopd)\n", j * 4 + section_address);
		      errcase = 3;
		      err++;
		    }
		  }
		} else if (((op2 & op_mask) == std_mask) ||
	                  ((op2 & op_mask) == st_mask)) {
		  fdest = (op1 >> 25) & 0x1f;
		  fdest2 = (op2 >> 25) & 0x1f;
		  if (!((op2 >> 19) & 1)) { /* ldf/stf */
		    if (fdest == fdest2) {
		      printf("ERROR 3 at %08x, (ldf/stf)\n", j * 4 + section_address);
		      errcase = 3;
		      err++;
		    }
		  } else {
		    fdest &= ~1;	/* ldf/stdf */
		    if (fdest == fdest2) {
		      printf("ERROR 3 at %08x, (ldf/stdf)\n", j * 4 + section_address);
		      errcase = 3;
		      err++;
		    }
		  }

		}
	      } else if ((op1 & op_mask) == ldd_mask) {
	        if ((op2 & FPop_mask) == FPop) {
		  fdest = (op1 >> 25) & 0x1e;
		  rs1 = (op2 >> 14) & 0x1e;
		  rs2 = (op2) & 0x1e;
		  if ((fdest == rs1) ||
		    ((((op2 >> 11) & 0x3) == 1) && (fdest == rs2))) {
		    if ((op2 >> 5) & 1) {	/* lddf/FPops */
		      printf("ERROR 3 at %08x, (lddf/FPops)\n", j * 4 + section_address);
		    } else {
		      printf("ERROR 3 at %08x, (lddf/FPopd)\n", j * 4 + section_address);
		    }
		    errcase = 3;
		    err++;
		  }
		} else if (((op2 & op_mask) == std_mask) ||
	                  ((op2 & op_mask) == st_mask)) {
		  fdest = (op1 >> 25) & 0x1e;
		  fdest2 = (op2 >> 25) & 0x1e;
		  if (fdest == fdest2) {
		    if (!((op2 >> 19) & 1)) { /* lddf/stf */
		      printf("ERROR 3 at %08x, (lddf/stf)\n", j * 4 + section_address);
		    } else {
		      printf("ERROR 3 at %08x, (lddf/stdf)\n", j * 4 + section_address);
		    }
		    errcase = 3;
		    err++;
		  }

		}
	      }
	    }

	    /* Check for ldfsr/stfsr errors */

	    if ((op1 & op_mask) == ldfsr_mask) {
	      if ((op2 & op_mask) == stfsr_mask) {
		printf("ERROR 2 at %08x, (ldfsr/stfsr)\n", j * 4 + section_address);
		errcase = 2;
		err++;
	      }
	    }


	    /* report error if verbose mode */

	    if (verbose && errcase) {
	      print_insn_sparc(j * 4, &dinfo);
	      printf("\n");
	      print_insn_sparc(j * 4 + 4, &dinfo);
	      printf("\n");
	    }
	    errcase = 0;
	  }
	  free(ibuf);
	  if (verbose)
	    if (err)
	      printf("\ntotal errors: %d\n", err);
	    else
	      printf(" (no errors found)\n");
	}
      }				/* BSS */
    }
  }
  return (bfd_get_start_address(pbfd));
}

buf_read(addr, buf, size, dinfo)
  bfd_vma         addr;
  bfd_byte       *buf;
  int             size;
  struct disassemble_info *dinfo;
{
  memcpy(buf, &buffer[addr], size);
  return (0);
}
