func edif2m (string des) {
  string edif_lib_name
  string mgc_symbol_path

  edif_lib_name = "ACT2"
  mgc_symbol_path = "$ALSDIR/lib/me/parts/"

  read_netlist @des
  convert_design @des @edif_lib_name @mgc_symbol_path
}

