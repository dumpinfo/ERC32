func edif2m (string des) {
  string edif_lib_name
  string mgc_symbol_path

  edif_lib_name = "MA9000A_SYN"
  mgc_symbol_path = "$GPS_MA9000a/components/"

  patch_netlist @des
  read_netlist "tmp"
  convert_design @des @edif_lib_name @mgc_symbol_path
  sh rm tmp.edif
}

