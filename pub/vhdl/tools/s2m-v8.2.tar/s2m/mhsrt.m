func edif2m (string des) {
  string edif_lib_name
  string mgc_symbol_path

  edif_lib_name = "MHSLIBRT"
  mgc_symbol_path = "$MHS_MCRT/parts/cells/"

  patch_netlist @des
  read_netlist "tmp"
  convert_design @des @edif_lib_name @mgc_symbol_path
  sh rm tmp.edif
}

